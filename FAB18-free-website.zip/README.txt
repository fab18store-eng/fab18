FAB18 WEBSITE

1. Open index.html in a browser to preview the website.
2. It is a static, mobile-friendly catalogue with WhatsApp order buttons.
3. WhatsApp number is configured as +91 98463 69329.
4. Replace demo product names, photos and prices in index.html before publishing.
5. Free publishing: create a GitHub account, create a public repository named fab18, upload index.html, then go to Settings > Pages > Deploy from a branch > main / root. GitHub Pages will provide a free public URL.
